#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>

char *isar_get_error(uint32_t err);