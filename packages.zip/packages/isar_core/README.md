# isar-core

The Rust core of the Isar database.