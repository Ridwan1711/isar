// unsupported type

import 'package:isar/isar.dart';

@collection
class Model {
  late int id;

  late Set<String>? prop;
}
