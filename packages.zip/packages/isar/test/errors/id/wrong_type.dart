// only int and string properties can be used as id

import 'package:isar/isar.dart';

@collection
class Test {
  late bool id;
}
