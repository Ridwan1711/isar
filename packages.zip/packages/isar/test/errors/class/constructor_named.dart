// unnamed constructor

import 'package:isar/isar.dart';

@collection
class Model {
  Model.create();

  late int id;
}
