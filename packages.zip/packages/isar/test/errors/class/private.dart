// must be public

import 'package:isar/isar.dart';

// Test case for private class validation
// ignore_for_file: avoid_classes_with_only_static_members

@collection
// ignore: unused_element - Test case for private class validation
class _Model {
  late int id;
}
