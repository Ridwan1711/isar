// only classes

import 'package:isar/isar.dart';

// Test case for enum validation
// ignore_for_file: avoid_classes_with_only_static_members

// ignore: invalid_annotation_target - Test case for enum validation
@collection
enum Test { a, b, c }
