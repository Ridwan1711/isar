## The fastest way to get started is by following the [Quickstart Guide](https://isar.dev/tutorials/quickstart.html)!

Have fun using Isar!