//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import isar_flutter_libs
import path_provider_foundation

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  IsarFlutterLibsPlugin.register(with: registry.registrar(forPlugin: "IsarFlutterLibsPlugin"))
  PathProviderPlugin.register(with: registry.registrar(forPlugin: "PathProviderPlugin"))
}
